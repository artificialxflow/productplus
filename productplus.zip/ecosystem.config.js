module.exports = {
  apps: [{
    name: 'productplus',
    script: 'server.js',
    cwd: '/home/swpricel/swpl.ir',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'development',
      PORT: 3000,
      DATABASE_URL: "mysql://swpricel_productsplus:Ronak@123Ronak@localhost:3306/swpricel_productsplus",
      NEXTAUTH_SECRET: "ey-name-to-behtarin-saraghaz-ey-name-to-behtarin-saraghaz",
      NEXTAUTH_URL: "http://localhost:3000",
      JWT_SECRET: "ey-name-to-behtarin-saraghaz-ey-name-to-behtarin-saraghaz"
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000,
      DATABASE_URL: "mysql://swpricel_productsplus:Ronak@123Ronak@localhost:3306/swpricel_productsplus",
      NEXTAUTH_SECRET: "ey-name-to-behtarin-saraghaz-ey-name-to-behtarin-saraghaz",
      NEXTAUTH_URL: "http://localhost:3000",
      JWT_SECRET: "ey-name-to-behtarin-saraghaz-ey-name-to-behtarin-saraghaz"
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
};
