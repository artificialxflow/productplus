#!/bin/bash

echo "🚀 Starting ProductPlus deployment..."

# Set environment
export NODE_ENV=production

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build the application
echo "🔨 Building the application..."
npm run build

# Generate Prisma client
echo "🗄️ Generating Prisma client..."
npx prisma generate

# Create logs directory
echo "📁 Creating logs directory..."
mkdir -p logs

# Start the application with PM2
echo "🚀 Starting the application..."
pm2 start ecosystem.config.js --env production

# Save PM2 configuration
echo "💾 Saving PM2 configuration..."
pm2 save

# Show status
echo "📊 Application status:"
pm2 status

echo "✅ Deployment completed successfully!"
echo "🌐 Your app should be running on port 3000"
echo "📝 Check logs with: pm2 logs productplus"
