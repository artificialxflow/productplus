import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Optimize for Liara deployment
  output: 'standalone',
  experimental: {
    optimizePackageImports: ['bootstrap-icons']
  },
  // Ensure Prisma works properly
  webpack: (config, { isServer }) => {
    if (isServer) {
      config.externals.push('@prisma/client');
    }
    return config;
  },
  // Domain configuration for swpl.ir
  assetPrefix: process.env.NODE_ENV === 'production' ? 'https://swpl.ir' : '',
  basePath: '',
  // Add domain configuration
  env: {
    NEXT_PUBLIC_DOMAIN: process.env.NEXT_PUBLIC_DOMAIN || 'https://swpl.ir',
    NEXT_PUBLIC_API_BASE_URL: process.env.NEXT_PUBLIC_API_BASE_URL || 'https://swpl.ir/api'
  }
};

export default nextConfig;
